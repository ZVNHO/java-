package Taxi;

public class Taxilnfo {
		   private String rName;
		   private int rPrice;
		   private int rLimitNumber;//수용인원
		   private int rSpareCount;//남은방갯수
		   
		   public Taxilnfo(String rName, int rPrice, int rLimitNumber, int rSpareCount) {
		                super();
		                this.rName = rName;
		                this.rPrice = rPrice;
		                this.rLimitNumber = rLimitNumber;
		                this.rSpareCount = rSpareCount;
		             }
		   public Taxilnfo() {}
		   
		   public String getrName() {
		      return rName;
		   }
		   public void setrName(String rName) {
		      this.rName = rName;
		   }
		   public int getrPrice() {
		      return rPrice;
		   }
		   public void setrPrice(int rPrice) {
		      this.rPrice = rPrice;
		   }
		   public int getrLimitNumber() {
		      return rLimitNumber;
		   }
		   public void setrLimitNumber(int rLimitNumber) {
		      this.rLimitNumber = rLimitNumber;
		   }
		   public int getrSpareCount() {
		      return rSpareCount;
		   }
		   public void setrSpareCount(int rSpareCount) {
		      this.rSpareCount = rSpareCount;
		   }
		   @Override
		   public String toString() {
		      return "TaxilInfo [자동차 유형:" + rName + ", 요금:" + rPrice + ", 승차 인원:" + rLimitNumber + ", 남은 자동차 수"
		            + rSpareCount + "]\n";
		   }
		   
		}
		 
