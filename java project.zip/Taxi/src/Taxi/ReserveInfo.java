package Taxi;

	import java.util.ArrayList;
	import java.util.List;
	 
	public class ReserveInfo {
	   private Taxilnfo h;
	   private Customer1 c;
	   private String date;//사용날짜
	   private int period;//숙박기간
	   private int reserveNo;//예약번호
	   private int reservecount;//예약수
	   private int rOwnNum; //객실
	   private int total;
	   
	   
	   public ReserveInfo(Taxilnfo h, Customer1 c, String date, int period, int reserveNo,int reservecount) {
	    super();
	    this.h = h;
	    this.c = c;
	    this.date = date;
	    this.period = period;
	    this.reserveNo = reserveNo;
	    this.reservecount = reservecount;
	    
	}
	public ReserveInfo(Taxilnfo h, Customer1 c, String date, int period, int reserveNo, int reservecount, int rOwnNum,int total) {
	    super();
	    this.h = h;
	    this.c = c;
	    this.date = date;
	    this.period = period;
	    this.reserveNo = reserveNo;
	    this.reservecount = reservecount;
	    this.rOwnNum = rOwnNum;
	    this.total = total;
	}
	public int getTotal() {
	    return total;
	}
	public void setTotal(int total) {
	    this.total = total;
	}
	public int getrOwnNum() {
	    return rOwnNum;
	}
	public void setrOwnNum(int rOwnNum) {
	    this.rOwnNum = rOwnNum;
	}
	 
	public Customer1 getC() {
	    return c;
	}
	public void setC(Customer1 c) {
	    this.c = c;
	}
	public int getReservecount() {
	    return reservecount;
	}
	public void setReservecount(int reservecount) {
	    this.reservecount = reservecount;
	}
	 
	public ReserveInfo() {}
	public Taxilnfo getH() {
	      return h;
	   }
	   public void setH(Taxilnfo h) {
	      this.h = h;
	   }
	   public String getDate() {
	      return date;
	   }
	   public void setDate(String date) {
	      this.date = date;
	   }
	   public int getPeriod() {
	      return period;
	   }
	   public void setPeriod(int period) {
	      this.period = period;
	   }
	 
	   public int getReserveNo() {
	      return reserveNo;
	   }
	 
	   public void setReserveNo(int reserveNo) {
	      this.reserveNo = reserveNo;
	   }
	 
	   @Override
	   public String toString() {
	      return "ReserveInfo [h=" + h + ", c=" + c + ", date=" + date + ", period=" + period + ", reserveNo=" + reserveNo
	            + "]";
	   }
	}
