package Taxi;



	import java.util.LinkedList;
	import java.util.List;
	import java.util.Scanner;
	 
	 
	public class Main{
	    static Scanner sc = new Scanner(System.in);
	 
	 
	    public static void main(String[] args) {
	        
	        CustomerManagement cm = new CustomerManagement();    
	        TaxiManagement hm = new TaxiManagement();
	        
	        LinkedList<Customer1> list = new LinkedList<Customer1>();
	        LinkedList<Customer1> login = new LinkedList<Customer1>();
	        List<Taxilnfo> list2 = new LinkedList<Taxilnfo>();
	    
	 
	 
	        login=(LinkedList<Customer1>) cm.name();
	        
	        
	        while(true) {
	            System.out.println("1.조회  2.예약  3.내 예약  4.내 회원정보  5:종료");
	            //3.예약확인 들어가면 체크인,체크아웃
	            //4.내 회원정보 들어가면 회원정보 수정하거나 삭제할수있음
	            System.out.print("선택하세요: ");
	            String input = sc.nextLine();
	            switch(input) {
	            case "1"://객실조회
	                list2=hm.info;
	                System.out.println(list2.toString());
	                break;
	                
	            case "2":
	                //객실예약
	                list2=hm.info;
	                
	                hm.reserve(list2, login);
	                
	                break;
	            case "3":
	                System.out.println("1:예약정보확인  2:체크인  3:체크아웃");
	                String input2=sc.nextLine();
	                switch (input2) {
	                case "1":
	                    //예약정보 확인
	                    hm.reserveAssure();
	                    break;
	                case "2":
	                    //예약번호를 가지고 객실을 배정
	                    
	                    hm.checkin();
	                    break;
	 
	 
	                case "3":
	                    hm.checkout();
	                    break;
	                }
	 
	 
	                break;
	            case "4":
	                System.out.println("1:회원정보 수정  2:회원정보 삭제");
	                String input3=sc.nextLine();
	                if(input3.equals("1")) {
	                    cm.updateCustomer();
	                    System.out.println(cm.list.toString());
	                }else if(input3.equals("2")) {
	                    cm.removeCustomer();
	                    System.out.println(cm.list.toString());
	                    login.remove();
	                }
	                
	                break;
	            case"5":
	                System.out.println("프로그램 종료");
	                return;
	            }    
	    }//while문
	    
	        
	    }
	}
